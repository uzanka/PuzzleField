User map folder.

1. Place the map file in this folder ({ClassName}/user/).
   Map style is ".json", ".xml" ".slc", or ".map".
2. Add or change the "auto_detect" key to "true" in "puzzle_field.json" file.
3. Run PuzzleField.exe application.
   Automatically detect and add map files.

